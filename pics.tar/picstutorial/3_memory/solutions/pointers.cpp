#include <iostream>

int main(){
  int x = 1;
  int *y = &x;
  int z = 4;

  std::cout << "x: " << *y << "\n";

  y = &z;

  std::cout << "z: " << *y << "\n";

  return 0;
}
