#include <iostream>

void changePointer(int **p){
  int y = 2;
  std::cout << "Pointer addr: " << (void*)p << "\n";
  *p = &y;
  std::cout << "Pointer addr: " << (void*)p << "\n";
}

void changeReference(int &r){
  int y = 2;
  std::cout << "Reference addr: " << (void*)&r << "\n";
  r = y;
  std::cout << "Reference addr: " << (void*)&r << "\n";
}

void printInt(int &r){
  std::cout << r << "\n";
}

int main(){
  int x = 0;
  int *p2 = &x;

  changePointer(p2);
  std::cout << "x: " << x << "\n";
  changeReference(x);
  std::cout << "x: " << x << "\n";

  return 0;
}
