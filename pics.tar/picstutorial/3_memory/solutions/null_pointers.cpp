#include <cstdlib>

int main(){
    int *p1;
    int *p2 = nullptr; // NULL

    *p1 = 0;
    *p2 = 0;

    return 0;
}
