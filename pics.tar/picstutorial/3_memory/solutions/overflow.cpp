int main(){
  //int *a = new int[10];
  int a[10];
    int c = 0;

    for(c = 0; c < 100; c++){
        a[c] = c;
    }

    //delete [] a;

    return 0;
}
