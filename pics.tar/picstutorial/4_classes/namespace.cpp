#include <iostream>

using namespace std;

namespace data_structure{
class vector{
  int *array;

  // ...
};
}

namespace numeric{

class vector{
  int x;
  int y;
  int z;
};
  
}

int main(){
  using namespace numeric;
  numeric::vector v;
  return 0;
}
