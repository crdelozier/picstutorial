#include <iostream>

class Base{
public:
  virtual void print(int x) final {
    std::cout << x << "\n";
  }
};

class Derived : public Base{
public:
  virtual void print(int x){
    std::cout << "Derived " << x << "\n";
  }
};
