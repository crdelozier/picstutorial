#include <stdlib.h>
#include <stdio.h>

typedef struct twod{
  int x;
  int y;
} twod;

typedef struct threed{
  twod p;
  int z;
} threed;

void f(twod *p){
  p->x = 5;
  p->y = 6;
}

int main(){
  twod *p1 = (twod*)malloc(sizeof(twod));
  threed *p2 = (threed*)malloc(sizeof(threed));

  f(p1);
  f((twod*)p2);

  printf("%d,%d\n",p1->x,p1->y);
  printf("%d,%d\n",p2->p.x,p2->p.y);

  free(p1);
  free(p2);

  return 0;
}
