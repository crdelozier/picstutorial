#include <iostream>
#include <cassert>

class Base{
protected:
  int x;
public:
  virtual void foo(){
    std::cout << "Base foo()\n";
  }
};

class Derived : public Base{
  int y;
public:
  virtual void foo(){
    std::cout << "Derived foo()\n";
  }

  void bar(){
  }
};

class Other : public Base{
  int *p;
};

int main(){
  //Base *b = new Base();
  Base *d = new Derived();

  //Derived *d2 = static_cast<Derived*>(d);
  Derived *d2 = dynamic_cast<Derived*>(d);
  assert(d2 != NULL);

  //b->foo();
  d->foo();
  d2->foo();

  if(dynamic_cast<Other*>(d)){
    // do something
  }

  Other *o = dynamic_cast<Other*>(d);
  assert(o != NULL);

  return 0;
}
