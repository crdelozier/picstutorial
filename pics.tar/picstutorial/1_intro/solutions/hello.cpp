#include <stdio.h>
#include <iostream>

int main(){
  printf("Number: %d\n","Hello World\n");
  //printf("Number: %d %d %d\n");
  std::cout << "Number: " << "Hello World" << "\n";
  //std::cout << "Hello World\n"; // printf("Hello World\n");
  return 0;
}
