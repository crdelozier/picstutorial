#include <stdio.h>

int main(void) {
  char c = 'X';
  short int s = 32;
  int i = -1024;
  long l = 32768;

  unsigned int u = 1024;

  if(i == u){
    printf("Unsigned and signed equal!\n");
  }

  float f = 0.5f;
  double d = 1.236;

  printf("%d\n",sizeof(char));  // 1
  printf("%d\n",sizeof(short int)); // 2
  printf("%d\n",sizeof(int)); // 4
  printf("%d\n",sizeof(long int)); // 8

  printf("%d\n",sizeof(unsigned int)); // 4

  printf("%d\n",sizeof(float)); // 4
  printf("%d\n",sizeof(double)); // 8

  return 0;
}
