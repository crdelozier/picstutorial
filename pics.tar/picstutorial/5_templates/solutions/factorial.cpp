#include <iostream>

template<int n>
class Factorial{
public:
  enum { value = n * Factorial<n-1>::value };
};

template<>
class Factorial<0> {
public:
  enum { value = 1 };
};

int factorial(int n){
  if(n == 0){
    return 1;
  }else{
    return n * factorial(n-1);
  }
}

int main(){
  std::cout << factorial(10) << "\n";
  std::cout << Factorial<10>::value << "\n";

  return 0;
}
